package com.example.demo.model.dto;

public class NotasDto {
	private int curso_id;
	private int rut_alumno;
	private int n_modulo;
	private int n_evaluacion;
	private int nota;
	private int promedio;
	
	public NotasDto() {
		
	}

	public int getCurso_id() {
		return curso_id;
	}

	public void setCurso_id(int curso_id) {
		this.curso_id = curso_id;
	}

	public int getRut_alumno() {
		return rut_alumno;
	}

	public void setRut_alumno(int rut_alumno) {
		this.rut_alumno = rut_alumno;
	}

	public int getN_modulo() {
		return n_modulo;
	}

	public void setN_modulo(int n_modulo) {
		this.n_modulo = n_modulo;
	}

	public int getN_evaluacion() {
		return n_evaluacion;
	}

	public void setN_evaluacion(int n_evaluacion) {
		this.n_evaluacion = n_evaluacion;
	}

	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public int getPromedio() {
		return promedio;
	}

	public void setPromedio(int promedio) {
		this.promedio = promedio;
	}
	
}
