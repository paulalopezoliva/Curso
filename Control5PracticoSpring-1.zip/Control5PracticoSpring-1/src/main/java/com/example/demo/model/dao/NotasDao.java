package com.example.demo.model.dao;

import java.util.List;

import com.example.demo.model.dto.NotasDto;

public interface NotasDao {
	public List<NotasDto> getnotas(int rut_alumno);
	
	public int updatenotas(NotasDto notasdto);
}
