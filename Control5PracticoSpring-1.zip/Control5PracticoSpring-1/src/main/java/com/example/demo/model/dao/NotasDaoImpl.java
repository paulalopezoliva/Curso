package com.example.demo.model.dao;

import java.util.List;

import com.example.demo.model.dto.NotasDto;

public class NotasDaoImpl implements NotasDao {
	private String getnotas="SELECT * FROM NOTAS WHERE RUT_ALUMNO=?";
	private String updatenotas="UPDATE NOTAS SET NOTA=?,  PROMEDIO=? WHERE RUT_ALUMNO=? AND ID_CURSO=?";
	@Override
	public List<NotasDto> getnotas(int rut_alumno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updatenotas(NotasDto notasdto) {
		// TODO Auto-generated method stub
		return 0;
	}

}
