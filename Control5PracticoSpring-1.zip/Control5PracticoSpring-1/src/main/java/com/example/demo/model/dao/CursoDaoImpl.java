package com.example.demo.model.dao;

public class CursoDaoImpl implements CursoDao {

}
