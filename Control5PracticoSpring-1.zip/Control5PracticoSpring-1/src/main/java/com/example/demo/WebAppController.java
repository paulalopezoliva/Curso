package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Servlet implementation class WebAppController
 */
@Controller
public class WebAppController  {
	@RequestMapping("/")
    public String getHome() {
    	return "index";
    }

	@RequestMapping("/Alumno")
    public String getAlumno() {
    	return "alumno";
}
}