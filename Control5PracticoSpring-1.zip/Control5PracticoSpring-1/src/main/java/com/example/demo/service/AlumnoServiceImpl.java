package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.dao.AlumnoDao;
import com.example.demo.model.dto.AlumnoDto;

@Service
public class AlumnoServiceImpl implements AlumnoService {

	@Autowired
	AlumnoDao alumnoDao;
	
	public AlumnoServiceImpl() {
		
	}

	@Override
	public List<AlumnoDto> lista() {
		// TODO Auto-generated method stub
		return alumnoDao.lista();
	}

	@Override
	public int update(AlumnoDto e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(AlumnoDto e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AlumnoDto getOne(Integer rut_alumno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Integer rut_alumno) {
		// TODO Auto-generated method stub
		return 0;
	}
}
