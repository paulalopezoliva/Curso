package com.example.demo.model.dto;


	public class AlumnoDto {

		private int rut_alumno;
		private String nombre_alumno;
		private int curso_id;
		
		public AlumnoDto() {
			
		}

		public int getRut_alumno() {
			return rut_alumno;
		}

		public void setRut_alumno(int rut_alumno) {
			this.rut_alumno = rut_alumno;
		}

		public String getNombre_alumno() {
			return nombre_alumno;
		}

		public void setNombre_alumno(String nombre_alumno) {
			this.nombre_alumno = nombre_alumno;
		}

		public int getCurso_id() {
			return curso_id;
		}

		public void setCurso_id(int curso_id) {
			this.curso_id = curso_id;
		}
		
	}


