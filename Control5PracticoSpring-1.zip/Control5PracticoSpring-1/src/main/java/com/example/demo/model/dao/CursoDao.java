package com.example.demo.model.dao;

public interface CursoDao {

}
