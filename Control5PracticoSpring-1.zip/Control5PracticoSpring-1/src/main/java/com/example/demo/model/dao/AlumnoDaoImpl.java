package com.example.demo.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.AlumnoDto;

@Repository
@Transactional
public class AlumnoDaoImpl implements AlumnoDao {
	public String insert="INSERT INTO ALUMNO VALUES(?,?,?)";
	public String update="UPDATE ALUMNO SET RUT_ALUMNO=?,  NOMBRE_ALUMNO=?, ID_CURSO=? WHERE RUT_ALUMNO=?";
	public String delete="DELETE FROM ALUMNO WHERE RUT_ALUMNO=?";
	public String get_one="SELECT * FROM ALUMNO WHERE RUT_ALUMNO=?";
	public String get_all="SELECT * FROM ALUMNO";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public AlumnoDaoImpl() {
	}
	@Override
	public List<AlumnoDto> lista() {
		List<AlumnoDto> listaalumno = jdbcTemplate.query(get_all, BeanPropertyRowMapper.newInstance(AlumnoDto.class));
		return listaalumno;
		
	}

	@Override
	public int update(AlumnoDto e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(AlumnoDto e) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AlumnoDto getOne(Integer rut_alumno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(Integer rut_alumno) {
		// TODO Auto-generated method stub
		return 0;
	}

}
