package com.example.demo.model.dao;

import java.util.List;

import com.example.demo.model.dto.AlumnoDto;



public interface AlumnoDao {
	public List<AlumnoDto> lista();
	
	public int update(AlumnoDto e);
	
	public int insert(AlumnoDto e);
	
	public AlumnoDto getOne(Integer rut_alumno);
	
	public int delete(Integer rut_alumno);
}
