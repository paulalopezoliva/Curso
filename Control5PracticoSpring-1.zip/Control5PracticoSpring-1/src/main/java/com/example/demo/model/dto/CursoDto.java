package com.example.demo.model.dto;

public class CursoDto {
	private int curso_id;
	private String nombre_curso;
	
	public CursoDto() {
		
	}

	public int getCurso_id() {
		return curso_id;
	}

	public void setCurso_id(int curso_id) {
		this.curso_id = curso_id;
	}

	public String getNombre_curso() {
		return nombre_curso;
	}

	public void setNombre_curso(String nombre_curso) {
		this.nombre_curso = nombre_curso;
	}
	
}
