package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Control5PracticoSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
